﻿Public Class HomeController
    Inherits System.Web.Mvc.Controller

    Function Index() As ActionResult
        Return View()
    End Function

    Function About() As ActionResult
        ViewData("Message") = "INICIO DE ACTIVIDADES"

        Return View()
    End Function

    Function Contact() As ActionResult
        ViewData("Message") = "INICIO DE ACTIVIDADES"

        Return View()
    End Function
End Class
